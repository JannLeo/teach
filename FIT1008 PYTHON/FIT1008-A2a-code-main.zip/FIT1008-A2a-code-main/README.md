# FIT1008 - Assignment 2 Scaffold

Please refer to Ed for the assignment specs and submission instructions.