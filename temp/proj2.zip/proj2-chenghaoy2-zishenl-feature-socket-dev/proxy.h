#ifndef PROXY_H
#define PROXY_H

void start_proxy_server(int port, int enable_cache);

#endif