class WhileDemo {
    public static void main(String[] args){
        int count = 0;
        while (count < 5) {
            System.out.println("Count is: " + count);
            count++;
        }

	
    }
}
