class IfDemo {
	public static void main(String[] args) {
		int a, b;
		a = 2;
		b = 3;
		if(a < b) System.out.println("a is less than b");
		
		// this won't display anything
		if(a == b)
		System.out.println("you won't see this");
	       

	}
}
