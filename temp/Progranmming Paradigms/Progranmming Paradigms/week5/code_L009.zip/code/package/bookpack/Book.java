
public class Book{
	private String title, author;
	private int pubDate;
	public Book(String t, String a, int d){
		title = t;
		author = a;
		pubDate = d;
	}
	public void show(){
		System.out.println("title: " + title);
		System.out.println("author: " + author);
		System.out.println("pubDate: " + pubDate);
	}
}
