
class BookDemo{
	public static void main(String[] args){
		mypack1.Book book = new mypack1.Book("CS", "Me", 2024);
	    book.show(); 
	}	
}	
