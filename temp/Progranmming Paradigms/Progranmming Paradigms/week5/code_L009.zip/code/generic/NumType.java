class NumType<T>{
    T num;
    NumType(T t){
	num = t;
    }

    multiply double(double x){
	return num * x;
    }

    public static void main(String args[]){
	NumType<Integer> it = new NumType<Integer>(2);
	
    }
}
