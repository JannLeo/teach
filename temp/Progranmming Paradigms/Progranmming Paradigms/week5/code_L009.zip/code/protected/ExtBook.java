package bookpack2;
//import bookpack.*;

class ExtBook extends bookpack.Book{
    private String condition;
    public ExtBook(String t, String a, int d, String c){
	super(t, a, d);
	condition = c;
    }	
    public void show(){
	super.show();
	System.out.println("Condition: " + condition);
    }

    // it works as title is declared as protected
    public String getTitle(){
	return title;
    }
}
