package bookpack2;
class BookDemo{
	public static void main(String[] args){
		ExtBook book = new ExtBook("CS", "Me", 2024,"T");
		System.out.println(book.getTitle());
		//book.title = "BS"; // will it work?
	}	
}
	
