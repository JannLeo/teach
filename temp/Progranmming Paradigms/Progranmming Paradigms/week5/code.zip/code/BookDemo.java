class BookDemo{
	public static void main(String[] args){
	    Book book = new Book("CS", "Me", 2022);
	    book.show(); 
	}	
}	
