1. Item 1
    1. Sub Item 1
    2. Sub Item 2
    3. Sub Item 3
2. **Bolded Item 2**
6. Item 3
7. Item 4
