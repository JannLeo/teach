```haskell
main :: IO ()
main = do
    putStrLn "Never gonna give you up"
    putStrLn "Never gonna let you down"
    putStrLn "Never gonna run around and desert you"
```
