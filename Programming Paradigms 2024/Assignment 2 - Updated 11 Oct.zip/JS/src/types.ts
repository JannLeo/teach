export type State = Readonly<{
    markdown: string;
    HTML: string;
    renderHTML: boolean;
    save: false;
}>;
