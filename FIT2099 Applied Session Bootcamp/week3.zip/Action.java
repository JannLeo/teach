public abstract class Action {
    public abstract String execute(Camper camper, Campsite campsite);
    public abstract String menuDescription(Camper camper);
}