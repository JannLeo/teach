package edu.monash.fit2099.engine.actors.attributes;

/**
 * Statistic Operations
 * @author Adrian Kristanto
 */
public enum ActorAttributeOperation {
    INCREASE,
    DECREASE,
    UPDATE
}
