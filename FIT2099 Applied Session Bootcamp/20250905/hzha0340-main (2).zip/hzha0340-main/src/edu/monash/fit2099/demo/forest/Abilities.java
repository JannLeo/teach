package edu.monash.fit2099.demo.forest;

public enum Abilities{
    CAN_ATTACK;
}
