package edu.monash.fit2099.demo.mars.capabilities;

public interface SpaceTravelling {
    void canTravel();
}
