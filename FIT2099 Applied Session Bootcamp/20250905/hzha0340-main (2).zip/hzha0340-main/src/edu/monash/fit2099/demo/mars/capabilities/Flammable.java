package edu.monash.fit2099.demo.mars.capabilities;

public interface Flammable {
    void burn(int damage);
}
