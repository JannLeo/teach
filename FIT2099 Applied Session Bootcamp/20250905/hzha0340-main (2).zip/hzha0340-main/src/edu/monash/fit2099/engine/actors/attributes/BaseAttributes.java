package edu.monash.fit2099.engine.actors.attributes;

/**
 * Attributes/Stats
 * @author Adrian Kristanto
 * @author Riordan Alfredo
 *
 */
public enum BaseAttributes {
    HEALTH,
    STAMINA,
    MANA,
}
