package edu.monash.fit2099.demo.conwayslife;

import edu.monash.fit2099.engine.capabilities.Status;
import edu.monash.fit2099.engine.positions.Ground;

public class Dirt extends Ground {

    public Dirt() {
        super('.', "Dirt");
        addStatus(new Alive());
    }
}
